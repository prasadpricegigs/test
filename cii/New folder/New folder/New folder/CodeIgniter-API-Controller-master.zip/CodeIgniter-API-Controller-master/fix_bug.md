# Fix Bug

## v.1.1.6

* fix bug in API Limit

## v.1.1.5

* If the database library did not load, the error was shown
* change API errors string
* modify documentation